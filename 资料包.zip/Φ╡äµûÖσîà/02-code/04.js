/*
    引入模块
*/

var module = require('./03.js');

// var ret = module.sum(12,13);
// console.log(ret);

// var ret = module(12,15);
// console.log(ret);   

// console.log(typeof module);
module();
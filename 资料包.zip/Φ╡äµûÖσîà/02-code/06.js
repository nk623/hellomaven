/*
    测试导出
*/

var m = require('./05.js');
console.log(m);
// var ret = m.sum(1,2);
// var ret1 = m.subtract(1,2);
// console.log(ret,ret1);

exports.showInfo = function(){
    console.log('nihao');
}